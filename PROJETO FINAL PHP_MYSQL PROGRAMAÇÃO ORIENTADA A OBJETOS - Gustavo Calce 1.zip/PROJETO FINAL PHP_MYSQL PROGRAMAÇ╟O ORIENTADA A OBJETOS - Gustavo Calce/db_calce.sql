-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2023 at 10:44 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_calce`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_insert_car` (IN `p_marca` VARCHAR(100), IN `p_modelo` VARCHAR(100), IN `p_ano_fabricacao` VARCHAR(100), IN `p_cor` VARCHAR(100), IN `p_preco` DECIMAL(10,2))   BEGIN
    DECLARE v_marca_id INT;
    DECLARE v_modelo_id INT;

    -- Verifica se a marca já existe na tabela marcas
    SELECT id_marca INTO v_marca_id FROM marcas WHERE marca = p_marca LIMIT 1;

    -- Se a marca não existe, insere uma nova marca
    IF v_marca_id IS NULL THEN
        INSERT INTO marcas (marca) VALUES (p_marca);
        SET v_marca_id = LAST_INSERT_ID();
    END IF;

    -- Verifica se o modelo já existe na tabela modelos
    SELECT id_modelo INTO v_modelo_id FROM modelos WHERE modelo = p_modelo LIMIT 1;

    -- Se o modelo não existe, insere um novo modelo
    IF v_modelo_id IS NULL THEN
        INSERT INTO modelos (modelo) VALUES (p_modelo);
        SET v_modelo_id = LAST_INSERT_ID();
    END IF;

    -- Insere o carro na tabela cars
    INSERT INTO cars (id_marca, id_modelo, ano_fabricacao, cor, preco)
    VALUES (v_marca_id, v_modelo_id, p_ano_fabricacao, p_cor, p_preco);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `id` int(11) NOT NULL,
  `id_marca` int(11) NOT NULL,
  `id_modelo` int(11) NOT NULL,
  `ano_fabricacao` date DEFAULT NULL,
  `cor` varchar(150) DEFAULT NULL,
  `preco` decimal(10,2) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`id`, `id_marca`, `id_modelo`, `ano_fabricacao`, `cor`, `preco`) VALUES
(35, 24, 48, '2023-06-07', 'Azul', 144000.00),
(38, 26, 50, '2023-06-17', 'Preto', 45000.00),
(40, 27, 51, '2023-06-15', 'Vinho', 80000.00),
(41, 28, 52, '2018-01-01', 'Branco', 92000.00);

-- --------------------------------------------------------

--
-- Table structure for table `marcas`
--

CREATE TABLE `marcas` (
  `id_marca` int(11) NOT NULL,
  `marca` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;

--
-- Dumping data for table `marcas`
--

INSERT INTO `marcas` (`id_marca`, `marca`) VALUES
(28, 'Jetta'),
(27, 'Honda'),
(26, 'Honda'),
(25, 'malu linda'),
(24, 'Honda'),
(23, 'malu linda');

-- --------------------------------------------------------

--
-- Table structure for table `modelos`
--

CREATE TABLE `modelos` (
  `id_modelo` int(11) NOT NULL,
  `modelo` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;

--
-- Dumping data for table `modelos`
--

INSERT INTO `modelos` (`id_modelo`, `modelo`) VALUES
(51, 'HR-V'),
(50, 'City'),
(49, 'Q3 competition'),
(48, 'Civic'),
(47, 'teste3'),
(52, 'GLI'),
(53, 'enzo');

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_carros`
-- (See below for the actual view)
--
CREATE TABLE `view_carros` (
`id` int(11)
,`marca` varchar(150)
,`modelo` varchar(150)
,`ano_fabricacao` date
,`cor` varchar(150)
,`preco` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Structure for view `view_carros`
--
DROP TABLE IF EXISTS `view_carros`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_carros`  AS SELECT `c`.`id` AS `id`, `m`.`marca` AS `marca`, `mo`.`modelo` AS `modelo`, `c`.`ano_fabricacao` AS `ano_fabricacao`, `c`.`cor` AS `cor`, `c`.`preco` AS `preco` FROM ((`cars` `c` join `marcas` `m` on(`c`.`id_marca` = `m`.`id_marca`)) join `modelos` `mo` on(`c`.`id_modelo` = `mo`.`id_modelo`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `marcas`
--
ALTER TABLE `marcas`
  ADD PRIMARY KEY (`id_marca`);

--
-- Indexes for table `modelos`
--
ALTER TABLE `modelos`
  ADD PRIMARY KEY (`id_modelo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `marcas`
--
ALTER TABLE `marcas`
  MODIFY `id_marca` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `modelos`
--
ALTER TABLE `modelos`
  MODIFY `id_modelo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
